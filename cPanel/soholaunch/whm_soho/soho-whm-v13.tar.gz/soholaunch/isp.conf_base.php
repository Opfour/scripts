<?php exit; ?>

#########################################################
### SOHOLAUNCH V4.9 CONFIGURATION SETUP
#########################################################

this_ip=#THISIP#

db_server=localhost
db_name=#DBUSERNAME#
db_un=#DBUSERNAME#
db_pw=#PASSWORD#

user_table=login
cgi_bin=#DOCROOT#/sohoadmin/tmp_content
doc_root=#DOCROOT#

dflogin_user=#LOGINUSER#
dflogin_pass=#LOGINPASS#


lang_set=english.php
lang_dir=#DOCROOT#/sohoadmin/language

template_lib=#DOCROOT#/sohoadmin/program/modules/site_templates/pages
undercon=

map_obj=enabled
df_template_cat=Neutral

#########################################################

